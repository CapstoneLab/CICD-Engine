# 웹 기반 DT KCI 논문 보조자료 S1

이 압축파일은 논문의 집계값과 재현성 정보를 검토하기 위한 제출용 보조자료이다.

포함 범위:
- 14개 공개 DT의 `pipeline_result.json`, `security_verdict.json`
- 코드 스니펫과 AI 권고문을 제거한 `security_findings.redacted.json`
- OWASP Benchmark v1.2 정답표와 비식별 정규화 탐지 결과
- 수동 판독 결과(코드 문맥 제거), 요약, 구성요소 제거·민감도·계보 분석 결과
- 고정 Semgrep 룰 번들, Gitleaks 설정, 정책 카탈로그
- 원시 산출물 SHA-256 목록과 분석 스크립트

보안상 원시 `gitleaks_report.json`과 코드 스니펫은 포함하지 않는다. 원시 결과의
동일성은 `analysis/reproducibility/experiment_output_sha256.csv`로 확인한다.
룰별 진단 수치는 `analysis/benchmark_rule_error_analysis.csv`에 보존되어 있다.

연구 코드 저장소: https://github.com/CapstoneLab/CICD-Engine
최종 게재본에는 원고 버전과 대응하는 릴리스 태그 또는 영구 보관 DOI를 추가해야 한다.
